A developer in China (Cheng Liang) identified a missing feature in the l10nInjection code. 
The Localization IOC did not support view state changes.


That feature is now working.
In the attached src is the updated l10nInjection.swc, the l10nInjection source code,
and an improved version of a sample/demo application.

Note:

MyLocaleMap.mxml -
   (line 19) using getItemAt() to get target for a non-binding data model.
   (line 22,23) using state="" to determine which viewState the ResourceProxy applies to.
   Also note the use of trigger="" provide extra control  on who is the IEventDispatcher for the STATE_CHANGE notification.

I18nTest.mxml -
   (line 32) toggle of view state when the accordion is clicked.
   (line 44) use of view states for the txtTitle component (changes size and color).

common-properties -
   (line 1,2) use of different keys for different states of the txtTitle

I hope you find the improvements beneficial and the changes to demo easy to
understand.